import os

os.system('python3 data/draw_net.py data/googlenet_deploy.prototxt googlenet.png')
os.system('python3 data/draw_net.py data/vgg16_deploy.prototxt vgg16.png')
os.system('python3 data/draw_net.py data/alexnet_deploy.prototxt alexnet.png')
